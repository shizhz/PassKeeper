package org.shizhz.exception;

public class BrokenRouteMatrixExcpetion extends RuntimeException {

  private static final long serialVersionUID = -8968692399149765009L;

  public BrokenRouteMatrixExcpetion(String message) {
    super(message);
  }
}
