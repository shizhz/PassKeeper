package org.shizhz.route;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

public class CityTest {

  @Test
  public void testCityToString() {
    City city = new City("Chengdu");
    Assert.assertEquals("Chengdu", city.toString());
    city.setName("Beijing");
    Assert.assertEquals("Beijing", city.toString());
  }
  
  @Test
  public void testCityEquality() {
    String name = "chengdu";
    City cd = new City(name);
    
    // reflexive
    Assert.assertTrue(cd.equals(cd)); 
    City cdNew = new City(name);
    
    // symmetric
    Assert.assertTrue(cd.equals(cdNew));
    Assert.assertTrue(cdNew.equals(cd));
    City cdEvenNewer = new City(name);
    
    // transitive
    Assert.assertTrue(cd.equals(cdNew));
    Assert.assertTrue(cdNew.equals(cdEvenNewer));
    Assert.assertTrue(cd.equals(cdEvenNewer));
    
    // null case
    Assert.assertTrue(new City(null).equals(new City("")));
    
    Assert.assertFalse(new City("A").equals(null));
    Assert.assertFalse(new City("A").equals("A"));
  }
  
  @Test
  public void testCompareTo() {
    Assert.assertTrue(new City("A").compareTo(new City("B")) < 0);
    Assert.assertTrue(new City("A").compareTo(new City("A")) == 0);
    Assert.assertTrue(new City("Z").compareTo(new City("A")) > 0);
    
    City[] cities = new City[] {
      new City("A"),
      new City("D"),
      new City("C")
    };
    
    Assert.assertArrayEquals(new City[] {
        new City("A"),
        new City("D"),
        new City("C")
    }, cities);
    
    Arrays.sort(cities);
    Assert.assertArrayEquals(new City[] {
        new City("A"),
        new City("C"),
        new City("D")
    }, cities);
  }
}
