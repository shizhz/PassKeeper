package org.shizhz;


/**
 * Main class for this program
 * 
 * @author shizhz
 *
 */
public class Main {
  
  public static void main(String[] args) {
    
  }
}
