package org.shizhz.util;

public class InputParser {

  private static final String INPUT_FILE = "routes.txt";
}
