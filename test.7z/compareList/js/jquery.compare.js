(function($) {
    'use strict';

    var SelectedComparingIds = [];
    var ON = true;
    var OFF = false;
    var Flags = {
        'MAX_NUMBER_EXCEEDED': OFF,
    };

    var defaultSettings = {
        compareBoxId: 'selectDiv',
        checkboxPrefix: 'compareCheckbox-',
        checkboxLabelPostfix: '-label',
        checkboxPricePostfix: '-price',
        selectedIdsTag: 'selectedIds',
        selectedIdsParaName: 'selectedIds',
        linkPrefix: 'offeringListLink-',
        maxAllowedNum: 2,
        selectedIdsSep: ',',
        notificationArea: 'notificationArea',
        notificationAreaClose: 'notificationAreaClose'
    };

    $.fn.compare = function(options) {
        var settings = $.extend(true, defaultSettings, options);

        var Notifier = {
            message: {
                'MAX_NUMBER_EXCEEDED': 'maxNumberExceededMessage',
            },

            notify: function() {
                var messages = [];
                var messageContainer = $('#' + settings.notificationArea);
                for (var key in Flags) {
                    if (Flags.hasOwnProperty(key) && Flags[key]) {
                        messages.push($('#' + this.message[key]).val());
                    }
                }

                messageContainer.empty().html(messages.join('<br/>');
            },

            init: function () {
                $('#' + settings.notificationAreaClose).click( function (event) {
                    $(this).parent().toggle(false);
                } );
            },
        };

        var Validator = {
            validate: function () {
                this.validateMaxNumberExceeded();

            },

            validateMaxNumberExceeded: function () {

            }
        };

        var Compare = {
            triggerChange: function() {
                this.flushCheckboxStatus();
                this.flushComparingDivBox();
                this.flushLinks();
            },

            getAllCheckboxes: function() {
                var checkboxSelector = 'input:checkbox[id^=' + settings.checkboxPrefix + ']';
                return $(checkboxSelector);
            },

            getAllCheckedboxes: function() {
                return SelectedComparingIds.map(function(offeringId) {
                    return settings.checkboxPrefix + offeringId;
                });
            },

            flushCheckboxStatus: function() {
                var checkedBoxes = this.getAllCheckedboxes();

                this.getAllCheckboxes().each(function() {
                    var checkboxId = $(this).attr('id');
                    $(this).attr('checked', checkedBoxes.indexOf(checkboxId) > -1);
                });
            },

            flushLinks: function() {
                $('a[id^=' + settings.linkPrefix + ']').each(function(event) {
                    var linkURL = $(this).attr('href');
                    var position = linkURL.indexOf('?');

                    if (position > 0) {
                        linkURL = linkURL.substring(0, position);
                    }

                    $(this).attr('href', linkURL + '?' + settings.selectedIdsParaName + "=" + SelectedComparingIds.join(settings.selectedIdsSep));

                });
            },

            flushComparingDivBox: function() {
                // flush items
                var that = this;
                var comparingBox = $('#' + settings.compareBoxId);
                var itemContainer = $('#items', comparingBox);
                itemContainer.empty();

                SelectedComparingIds.forEach(function(offeringId) {
                    var name = $('#' + settings.checkboxPrefix + offeringId + settings.checkboxLabelPostfix).val();
                    var price = $('#' + settings.checkboxPrefix + offeringId + settings.checkboxPricePostfix).val();

                    var createItem = function() {
                        var offerItem = $('<div>', {
                            'class': 'item',
                            'id': 'item_' + offeringId
                        });
                        var content = $('<div>', {
                            'class': 'content'
                        });

                        content.append($('<div>', {
                            'class': 'productname'
                        }).text(name));
                        content.append($('<div>', {
                            'class': 'productprice'
                        }).text(price));
                        $('<a>', {
                            'class': 'removebtn',
                            'href': 'javascript:void(0);'
                        }).click(function(event) {
                            SelectedComparingIds = SelectedComparingIds.filter(function(ele) {
                                return ele != offeringId;
                            });
                            that.triggerChange();
                            event.preventDefault();
                        }).appendTo(offerItem);

                        offerItem.append(content);

                        return offerItem;
                    };

                    createItem().appendTo(itemContainer);
                });

                // flush header
                $('.currentnum', comparingBox).html(SelectedComparingIds.length);
                $('.maxnum', comparingBox).html(settings.maxAllowedNum);

                // toggle visibility
                comparingBox.toggle(SelectedComparingIds.length > 0);
            },

            registerCheckboxClick: function() {
                var checkboxes = this.getAllCheckboxes();
                var that = this;
                checkboxes.each(function() {
                    $(this).click(function(event) {
                        var clickedId = $(this).val();

                        if ($(this).is(':checked')) {
                            SelectedComparingIds.push(clickedId);
                        } else {
                            SelectedComparingIds = SelectedComparingIds.filter(function(offeringId) {
                                return offeringId != clickedId;
                            });
                        }
                        that.triggerChange();
                    });
                });
            },

            registerClearAll: function() {
                var that = this;
                $('#compareBtnClearAll').click(function(event) {
                    SelectedComparingIds = [];
                    that.triggerChange();
                    event.preventDefault();
                });
            },

            registerCompareNow: function() {
                var that = this;
                $('#compareBtnCompareNow').click(function(event) {
                    var selectedIds = SelectedComparingIds.join(settings.selectedIdsSep);
                    var baseURL = $(this).attr('href');
                    $(this).attr('href', baseURL + '?' + settings.selectedIdsParaName + "=" + selectedIds);
                });
            },

            initSelectedComparingIds: function() {
                var ids = $('#' + settings.selectedIdsTag).val();
                ids = ids || '';
                SelectedComparingIds = ids.split(settings.selectedIdsSep).map(function(item) {
                    return $.trim(item);
                }).filter(function(item) {
                    return item.length > 0;
                });
            },

            init: function() {
                var maxAllowed = $('#maxAllowedNumber').val();
                settings.maxAllowedNum = maxAllowed || settings.maxAllowedNum;

                this.initSelectedComparingIds();
                this.triggerChange();
                this.registerCheckboxClick();
                this.registerClearAll();
                this.registerCompareNow();
            },
        };

        Compare.init();
        Notifier.init();
        return this;
    };
})(jQuery);

$(function() {
    $('#selectDiv').compare();
});
