(function ($) {

var Compare ={
	      select:{
		    params:{
				     'notifyClass':'notifyDiv',
					 'selectClass':'selectDiv',
					 'notifyDivBottom':150,
					 'selectDivBottom':0,
					 'maxnum':5,
					 'compareName':'Compare',
					 'compareButtonName':'Compare Now',
					 'clearButtonName':'Clear All',
					 'message':'Just support a maximum of ${num} items'
				   },
	        init : function(params_,isActive){
				    if(isActive){
						 if(typeof(params_)=='object'){
						   params = $.extend(Compare.select.params,params_);
						 }
						  Compare.select.createHTML();
						  // Compare.select.layoutbox();
						  $(window).scroll(function(){
								// Compare.select.layoutbox();
						  });
						  $("input[type=checkbox]").attr('checked',false);
						  Compare.select.registerCheckboxClick();
					}
	               },
		    createHTML:function(){
				     /*if(!$("#notifyDiv")[0]){
					  var notifyStr= "<div id='notifyDiv' onclick='Compare.select.oc();' class='"+Compare.select.params.notifyClass+"'>"+Compare.select.params.compareButtonName
					                 +"</div>";
						 $(notifyStr).appendTo(".offers_list_msdp");
					 }*/
					 if(!$("#selectedDiv")[0]){
						 var selectStr = "<div id='selectDiv' class='"+Compare.select.params.selectClass+"'>"
						                  + "<div class='header'>"
										  +  "<span class='mark'>"+Compare.select.params.compareName+"</span>(<span class='currentnum'>0</span>/"
										  +   "<span class='maxnum'>"+Compare.select.params.maxnum+"</span>)"
										  //+  "<a href='javascript:;' class='ocicon' onClick='Compare.select.oc()'  target='_self'></a>"
										  + "</div>"
										  + "<div class='list'>"
										  +    "<div id='items'>"

										  +    "</div>"
										  +  "<div class='option'>"
										  +   "<a href='javascript:;' class='vsBtn' target='_self'>"+Compare.select.params.compareButtonName+"</a>"
										  +   "<a href='javascript:;' class='cpClear' onclick='Compare.select.clearAll()'>"+Compare.select.params.clearButtonName+"</a>"
										  +  "</div>"
						                  +"</div>";
						 $(selectStr).appendTo(".offers_list_msdp");
					 }
				   },
			layoutbox:function(){
				   var scollTop = document.documentElement.scrollTop || document.body.scrollTop;
				   $("#selectDiv").css({'bottom':(Compare.select.params.selectDivBottom-scollTop)+'px'});
				   $("#notifyDiv").css({'bottom':(Compare.select.params.notifyDivBottom-scollTop)+'px'});
				},
		    oc:function(){
				    $("#selectDiv").toggle();
				},
			createItem:function(name,price,id){
				    var itemHTML = "<div class='item' id='item_"+id+"'>"
					              +    "<div class='content'>"
								  +         "<div class='productname'>"+name+"</div>"
								  +         "<div class='productprice'>"+price+"</div>"
								  +     "</div>"
								  +     "<a href='javascript:;' class='removebtn'></a>"
								  +      "<input type='hidden'  value=\'"+id+"\'/>"
								  + "</div>"
				    return itemHTML;
				},
			registerRemove:function(){
					    $(".removebtn").click(function(){
								var val = $(this).next().val();
								$("#checkbtn_"+val).attr('checked',false);
							 	$(this).parent('.item').remove();
								var num = Compare.select.getItemSize();
								Compare.select.changeCurrentNum(num);
								if(num==0){
						           $("#selectDiv").hide();
								   $("#notifyDiv").hide();
						        }
		                });

			    },
			registerCheckboxClick:function(){
				       $(":checkbox").click(function(){
								var parent = $(this).parents(".offers_offeritem_msdp");
							    var offersId = parent.find("input[type=hidden]").val();
								var num = Compare.select.getItemSize();
							   if($(this).is(':checked')){
								    if(num-Compare.select.params.maxnum>=0){
										 alert(Compare.select.getshowMessage());
										 $(this).attr('checked',false);
									}else{
										 $("#selectDiv").show();
										 $("#notifyDiv").show();
										 var offersName = parent.find(".offers_offername_msdp").text();
										 var offersPrice = parent.find(".offers_offerprice_msdp").text();
										 var product = Compare.select.createItem(offersName,offersPrice,offersId);
										 $(product).appendTo("#items");
									}
								}else{
									$("#item_"+offersId).remove();
								}
								num = Compare.select.getItemSize();
								Compare.select.changeCurrentNum(num);
								if(num==0){
									$("#selectDiv").hide();
									$("#notifyDiv").hide();
								}else{
									$("#selectDiv").show();
									$("#notifyDiv").show();
								}
					            Compare.select.registerRemove();

					   });

				},
			clearAll:function(){
				  $(".item").remove();
				  $("#selectDiv").hide();
				  $("input[id*=checkbtn_]").attr('checked',false);
			   },
			getItemSize:function(){
				  return $("#selectDiv .list .item").size();
			 },
			 changeCurrentNum:function(num){
				   $(".currentnum").html(num);
			 },
			 getshowMessage:function(){
			     return Compare.select.params.message.replace(/\$\{num\}/,Compare.select.params.maxnum);
		     }


	      }
	};


}) (jQuery);
