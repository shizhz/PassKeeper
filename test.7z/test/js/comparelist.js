﻿(function($){
     $(function(){	   
	     $(".offers_offeritem_msdp .header a").click(function(event){		    
		      event.preventDefault();
			  var content = $(this).parent().next();
			  if(content.is(':hidden')){
			     $(this).removeClass('offers_openincon_msdp').addClass('offers_closeincon_msdp');
			     content.slideDown(400);
			  }else{
			     $(this).removeClass('offers_closeincon_msdp').addClass('offers_openincon_msdp');
			     content.slideUp(400);
			  }
		      
		 });
	 
	 });

  }
)(jQuery)