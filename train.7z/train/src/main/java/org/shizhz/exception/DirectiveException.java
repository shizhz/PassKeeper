package org.shizhz.exception;

public class DirectiveException extends Exception {

    private static final long serialVersionUID = 1281141861422032564L;

    public DirectiveException(String message) {
        super(message);
    }
    
    public DirectiveException(Throwable e) {
    	super(e);
    }
}
