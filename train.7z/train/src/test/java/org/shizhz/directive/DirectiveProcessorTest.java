package org.shizhz.directive;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.shizhz.directive.DirectiveParser;
import org.shizhz.directive.DirectiveProcessor;
import org.shizhz.exception.DirectiveException;
import org.shizhz.exception.UnRecognizedDirectiveException;

public class DirectiveProcessorTest {

	private DirectiveProcessor processor;

	private DirectiveParser parser;
	private String routesInput = "AB5, BC4, CD8, DC8, DE6, AD5, CE2, EB3, AE7";

	@Before
	public void setup() {
		processor = DirectiveProcessor.newInstance();
		parser = DirectiveParser.newInstance();
	}

	@Test
	public void testProcessNull() throws DirectiveException {
		assertEquals("", processor.process(""));
	}
	
	@Test
	public void testProcessUncognizedDirectiveException () {
		try {
			processor.process("asdf d");
		} catch(Exception e) {
			assertEquals(UnRecognizedDirectiveException.class, e.getCause().getClass());
		}
	}

	@Test
	public void testProcessAddRoute() throws DirectiveException {
		assertEquals("Done", processor.process(parser.parse("g AB2, AC4")));
	}

	@Test(expected = DirectiveException.class)
	public void testProcessAddRouteException() throws DirectiveException {
		try {
			processor.process(parser.parse("g"));
		} catch (Exception e) {
			assertEquals(DirectiveException.class, e.getClass());
		}

		try {
			processor.process(parser.parse("g AB2 AB4"));
		} catch (Exception e) {
			assertEquals(DirectiveException.class, e.getClass());
		}

		processor.process(parser.parse("g A-E-D"));
	}

	@Test(expected = DirectiveException.class)
	public void testProcessFindDistanceException() throws DirectiveException {
		try {
			processor.process(parser.parse("d"));
		} catch (Exception e) {
			assertEquals(DirectiveException.class, e.getClass());
		}

			processor.process(parser.parse("d AB"));

	}
	
	@Test
	public void testProcessFindDistance()  throws DirectiveException { 
		processor.process(parser.parse("g " + routesInput));
		assertEquals("A-B-C : 9\n", processor.process(parser.parse("d A-B-C")));
		assertEquals("A-D : 5\nA-D-C : 13\n", processor.process(parser.parse("d a-d, A-D-C")));
		assertEquals("A-D : 5\nE-A : NO SUCH ROUTE\n", processor.process(parser.parse("d a-d, E-A")));
	}
	
	@Test(expected = DirectiveException.class)
	public void testProcessTripsWithStopsException() throws DirectiveException {
		try {
			processor.process(parser.parse("ts"));
		} catch (Exception e) {
			assertEquals(DirectiveException.class, e.getClass());
		}

		try {
			processor.process(parser.parse("ts AB"));
		} catch (Exception e) {
			assertEquals(DirectiveException.class, e.getClass());
		}
		
		try {
			processor.process(parser.parse("ts A-B-c"));
		} catch (Exception e) {
			assertEquals(DirectiveException.class, e.getClass());
		}
		
		try {
			processor.process(parser.parse("ts A-B-c, a"));
		} catch (Exception e) {
			assertEquals(DirectiveException.class, e.getClass());
		}

		try {
			processor.process(parser.parse("ts A-B-c, -1"));
		} catch (Exception e) {
			assertEquals(DirectiveException.class, e.getClass());
		}
		
		processor.process(parser.parse("g " + routesInput));
		processor.process(parser.parse("ts A-E-D, 2"));
	}
	
	@Test
	public void testProcessTripsWithStops() throws DirectiveException {
		processor.process(parser.parse("g " + routesInput));
		assertEquals("A-C : 3", processor.process("ts a-c, 4"));
	}
	
	@Test(expected = DirectiveException.class)
	public void testProcessTripsWithMaximumStopsException() throws DirectiveException {
		try {
			processor.process(parser.parse("tms"));
		} catch (Exception e) {
			assertEquals(DirectiveException.class, e.getClass());
		}

		try {
			processor.process(parser.parse("tms AB"));
		} catch (Exception e) {
			assertEquals(DirectiveException.class, e.getClass());
		}
		
		try {
			processor.process(parser.parse("tms A-B-c"));
		} catch (Exception e) {
			assertEquals(DirectiveException.class, e.getClass());
		}
		
		try {
			processor.process(parser.parse("tms A-B-c, a"));
		} catch (Exception e) {
			assertEquals(DirectiveException.class, e.getClass());
		}

		try {
			processor.process(parser.parse("tms A-B-c, -1"));
		} catch (Exception e) {
			assertEquals(DirectiveException.class, e.getClass());
		}
		
		processor.process(parser.parse("g " + routesInput));
		processor.process(parser.parse("tms A-E-D, 2"));
	}
	
	@Test
	public void testProcessTripsWithMaximumStops() throws DirectiveException {
		processor.process(parser.parse("g " + routesInput));
		assertEquals("C-C : 2", processor.process("tms c-c, 3"));
	}
	
	@Test(expected = DirectiveException.class)
	public void testProcessTripsLessThanDistanceException() throws DirectiveException {
		try {
			processor.process(parser.parse("tltd"));
		} catch (Exception e) {
			assertEquals(DirectiveException.class, e.getClass());
		}

		try {
			processor.process(parser.parse("tltd AB"));
		} catch (Exception e) {
			assertEquals(DirectiveException.class, e.getClass());
		}
		
		try {
			processor.process(parser.parse("tltd A-B-c"));
		} catch (Exception e) {
			assertEquals(DirectiveException.class, e.getClass());
		}
		
		try {
			processor.process(parser.parse("tltd A-B-c, a"));
		} catch (Exception e) {
			assertEquals(DirectiveException.class, e.getClass());
		}

		try {
			processor.process(parser.parse("tltd A-B, -1"));
		} catch (Exception e) {
			assertEquals(DirectiveException.class, e.getClass());
		}
		
		processor.process(parser.parse("g " + routesInput));
		processor.process(parser.parse("tltd A-D, 2"));
	}
	
	@Test
	public void testProcessTripsLessThanDistance() throws DirectiveException {
		processor.process(parser.parse("g " + routesInput));
		assertEquals("C-C : 7", processor.process("tltd c-c, 30"));
	}
	

	@Test(expected = DirectiveException.class)
	public void testProcessFindShortestPathException() throws DirectiveException {
		try {
			processor.process(parser.parse("sd"));
		} catch (Exception e) {
			assertEquals(DirectiveException.class, e.getClass());
		}

			processor.process(parser.parse("sd AB"));
	}
	
	@Test
	public void testProcessFindShortestPath()  throws DirectiveException { 
		processor.process(parser.parse("g " + routesInput));
		assertEquals("A-C : 9\nB-B : 9\n", processor.process(parser.parse("sd A-C,B-B")));

		assertEquals("A-A : NO SUCH ROUTE\n", processor.process(parser.parse("sd a-a")));
	}
}
