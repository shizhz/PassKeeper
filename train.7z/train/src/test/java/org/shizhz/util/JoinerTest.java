package org.shizhz.util;

import org.junit.Assert;
import org.junit.Test;

public class JoinerTest {

  @Test
  public void testJoinStringSet() {
    Assert.assertEquals("", Joiner.on(",").join(null));
    Assert.assertEquals("", Joiner.on(",").join(new String[] {}));
    Assert.assertEquals(",", Joiner.on(",").join(new String[] {"", ""}));
    Assert.assertEquals("A", Joiner.on("-").join(new String[] {"A"}));
    Assert.assertEquals("A-B-C", Joiner.on("-").join(new String[] {"A", "B", "C"}));
  }
}
