package org.shizhz;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.shizhz.directive.DirectiveProcessor;
import org.shizhz.exception.DirectiveException;

/**
 * Main class for this program
 * 
 * @author shizhz
 * 
 */
public final class Main {
    private static void usage() {
        System.out.println("Usage: ");
        System.out
                .println("\t`java -jar train-cli-1.0.jar -i` to enter the interactive mode. OR");
        System.out
                .println("\t`java -jar train-cli-1.0.jar -f <input file>` to use the file as input.");
    }

    private void run(InputStream is) {
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        String directive = "";
        DirectiveProcessor processor = DirectiveProcessor.newInstance();
        try {
            System.out.println("> ");
            while ((directive = br.readLine()) != null) {
                if (directive.trim().startsWith("#")) {
                    continue;
                }
                try {
                    System.out.println(processor.process(directive));
                } catch (DirectiveException e) {
                    System.out.print(e.getMessage());
                }
                System.out.println("> ");
            }
        } catch (IOException ioe) {
            System.out.println("Unexception Exception Happened: "
                    + ioe.getMessage());
        }
    }

    private void interactiveMode() {
        run(System.in);
    }

    private void oneTimeMode(String filePath) throws FileNotFoundException {
        run(new FileInputStream(new File(filePath)));
    }

    public static void main(String[] args) {
        Main main = new Main();
        for(String arg : args) {
            System.out.println(arg);
        }
        if (args.length == 0 || args.length > 2) {
            usage();
            return;
        }
        if ("-i".equals(args[0].trim())) {
            main.interactiveMode();
        } else if (args[0].trim() == "-f" && args.length == 2) {
            try {
                main.oneTimeMode(args[1]);
            } catch (FileNotFoundException e) {
                System.out.println("Input file not found");
            }
        } else {
            usage();
        }
    }
}
